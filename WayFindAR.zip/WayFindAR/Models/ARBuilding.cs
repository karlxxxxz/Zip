﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WayFindAR.Models
{
    [Table("ARBuildings")]
    public class ARBuilding
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        [MaxLength(500)]
        public string Description { get; set; }

        [Required]
        [MaxLength(100)]
        public string Position { get; set; }  // Format: "x,y,z" coordinates

        [MaxLength(50)]
        public string ModelType { get; set; }  // e.g., "main", "library", "science"

        [MaxLength(50)]
        public string Category { get; set; }  // e.g., "Academic", "Administration", "Recreation"

        [MaxLength(50)]
        public string FloorLevel { get; set; }  // e.g., "Ground Floor", "Level 1"

        // REMOVED: public string ImageUrl { get; set; }
        // REMOVED: public string QRCode { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public DateTime? UpdatedAt { get; set; }
    }
}