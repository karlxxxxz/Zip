﻿using System.ComponentModel.DataAnnotations;

namespace WayFindAR.Models
{
    public class RegisterModel
    {
        [Required(ErrorMessage = "Full Name is required")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required(ErrorMessage = "Campus ID is required")]
        [Display(Name = "Student/Staff ID")]
        public string CampusId { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Username is required")]
        [Display(Name = "Username")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [DataType(DataType.Password)]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = "Please confirm your password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Passwords do not match")]
        [Display(Name = "Confirm Password")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Please select account type")]
        [Display(Name = "Account Type")]
        public string AccountType { get; set; } = "Student";

        [Range(typeof(bool), "true", "true", ErrorMessage = "You must agree to the Terms and Privacy Policy")]
        [Display(Name = "Agree to Terms")]
        public bool AgreeToTerms { get; set; }
    }
}
