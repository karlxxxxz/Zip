﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WayFindAR.Models
{
    [Table("DestinationSearches")]
    public class DestinationSearch
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        // Foreign key to User (optional - only if user is logged in)
        public int? UserId { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }

        [Required]
        [MaxLength(100)]
        public string SearchQuery { get; set; }

        // If they selected a building from search results
        public int? SelectedBuildingId { get; set; }

        [ForeignKey("SelectedBuildingId")]
        public virtual ARBuilding SelectedBuilding { get; set; }

        // Search result data
        public string SearchResults { get; set; }  // JSON string of search results

        [MaxLength(50)]
        public string Category { get; set; }  // e.g., "Academic", "Services", "Sports", "Residence"

        // Location context
        [MaxLength(100)]
        public string UserLocation { get; set; }  // "x,y,z" coordinates if available

        [MaxLength(100)]
        public string DestinationCoordinates { get; set; }  // "x,y,z" of selected destination

        // Time tracking
        public DateTime SearchedAt { get; set; } = DateTime.Now;

        public DateTime? SelectedAt { get; set; }

        public DateTime? NavigationStartedAt { get; set; }

        public DateTime? NavigationCompletedAt { get; set; }

        // Additional analytics
        public int SearchResultCount { get; set; }

        public bool WasSuccessful { get; set; }  // Did they find what they wanted?

        public string DeviceInfo { get; set; }  // Browser/device info

        public string SessionId { get; set; }  // To track anonymous users
    }
}