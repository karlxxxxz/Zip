﻿using Microsoft.EntityFrameworkCore;
using WayFindAR.Models;

namespace WayFindAR.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<ARBuilding> ARBuildings { get; set; }
        public DbSet<DestinationSearch> DestinationSearches { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure ARBuildings table
            modelBuilder.Entity<ARBuilding>()
                .HasIndex(b => b.Name)
                .IsUnique();

            modelBuilder.Entity<ARBuilding>()
                .Property(b => b.CreatedAt)
                .HasDefaultValueSql("GETDATE()");

            // Seed initial AR building data (FIXED CAPITALIZATION)
            // In ApplicationDbContext.cs, update the seed data:
            modelBuilder.Entity<ARBuilding>().HasData(
                new ARBuilding
                {
                    Id = 1,
                    Name = "Main Building",
                    Description = "Administration and offices",
                    Position = "0,0,0",
                    ModelType = "main",
                    Category = "Administration",
                    FloorLevel = "Ground Floor",
                    // REMOVE: ImageUrl = "",
                    IsActive = true,
                    CreatedAt = DateTime.Now
                },
                new ARBuilding
                {
                    Id = 2,
                    Name = "Library",
                    Description = "Study resources center",
                    Position = "2,0,1",
                    ModelType = "library",
                    Category = "Academic",
                    FloorLevel = "Ground Floor",
                    // REMOVE: ImageUrl = "",
                    IsActive = true,
                    CreatedAt = DateTime.Now
                },
                new ARBuilding
                {
                    Id = 3,
                    Name = "Science Center",
                    Description = "Laboratories and research",
                    Position = "-2,0,-1",
                    ModelType = "science",
                    Category = "Academic",
                    FloorLevel = "Level 1",
                    // REMOVE: ImageUrl = "",
                    IsActive = true,
                    CreatedAt = DateTime.Now
                },
                new ARBuilding
                {
                    Id = 4,
                    Name = "Main Cafeteria",
                    Description = "Food court and dining area",
                    Position = "1,0,2",
                    ModelType = "cafeteria",
                    Category = "Services",
                    FloorLevel = "Ground Floor",
                    // REMOVE: ImageUrl = "",
                    IsActive = true,
                    CreatedAt = DateTime.Now
                }
            );

            // REMOVED unique constraints for smooth registration:
            // No HasIndex calls for Users table

            // Configure DestinationSearches table
            modelBuilder.Entity<DestinationSearch>()
               .HasIndex(d => d.UserId);

            modelBuilder.Entity<DestinationSearch>()
                .HasIndex(d => d.SearchedAt);

            modelBuilder.Entity<DestinationSearch>()
                .HasIndex(d => d.Category);

            modelBuilder.Entity<DestinationSearch>()
                .Property(d => d.SearchedAt)
                .HasDefaultValueSql("GETDATE()");

            // Relationships for DestinationSearch
            modelBuilder.Entity<DestinationSearch>()
                .HasOne(d => d.User)
                .WithMany()
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<DestinationSearch>()
                .HasOne(d => d.SelectedBuilding)
                .WithMany()
                .HasForeignKey(d => d.SelectedBuildingId)
                .OnDelete(DeleteBehavior.SetNull);

            // Seed initial test user
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    FullName = "Test Student",
                    CampusId = "CS2023001",
                    Email = "student@campus.edu",
                    Username = "student",
                    PasswordHash = "campus123",
                    AccountType = "Student",
                    CreatedAt = DateTime.Now,
                    IsActive = true
                }
            );
        }
    }
}
