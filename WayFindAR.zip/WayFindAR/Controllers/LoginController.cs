﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WayFindAR.Data;
using WayFindAR.Models;

namespace WayFindAR.Controllers
{
    public class LoginController : Controller
    {
        private readonly ApplicationDbContext _context;

        public LoginController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("IsLoggedIn") == "true")
            {
                return RedirectToAction("Index", "Home");
            }

            if (TempData["SuccessMessage"] != null)
            {
                ViewBag.SuccessMessage = TempData["SuccessMessage"];

                if (TempData["RegisteredUsername"] != null)
                {
                    ViewBag.PrefillUsername = TempData["RegisteredUsername"];
                }
            }

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(LoginModel model)
        {
            if (ModelState.IsValid)
            {
                // Find user by username and password
                var user = await _context.Users
                    .FirstOrDefaultAsync(u => u.Username == model.Username &&
                                             u.PasswordHash == model.Password && // Direct password check
                                             u.IsActive);

                if (user != null)
                {
                    // Update last login time
                    user.LastLoginAt = DateTime.Now;
                    await _context.SaveChangesAsync();

                    // Set session
                    HttpContext.Session.SetString("IsLoggedIn", "true");
                    HttpContext.Session.SetString("UserId", user.Id.ToString());
                    HttpContext.Session.SetString("Username", user.Username);
                    HttpContext.Session.SetString("FullName", user.FullName);
                    HttpContext.Session.SetString("AccountType", user.AccountType);
                    HttpContext.Session.SetString("CampusId", user.CampusId);

                    return RedirectToAction("Index", "Home");
                }

                ViewBag.Error = "Invalid username or password!";
            }

            return View(model);
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Login");
        }
    }
}
