using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WayFindAR.Data;
using WayFindAR.Models;
using WayFindAR.Services;
using System.Diagnostics;

namespace WayFindAR.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly DestinationTrackerService _trackerService;

        public HomeController(ApplicationDbContext context, DestinationTrackerService trackerService)
        {
            _context = context;
            _trackerService = trackerService;
        }

        public IActionResult Index()
        {
            // Check if user is logged in
            if (HttpContext.Session.GetString("IsLoggedIn") != "true")
            {
                return RedirectToAction("Index", "Login");
            }
            return View();
        }

        [HttpGet]
        public async Task<JsonResult> GetBuildings()
        {
            // Get all active buildings from database
            var buildings = await _context.ARBuildings
                .Where(b => b.IsActive)
                .OrderBy(b => b.Name)
                .ToListAsync();

            return Json(buildings);
        }

        [HttpGet]
        public async Task<JsonResult> GetBuilding(int id)
        {
            // Get specific building by ID
            var building = await _context.ARBuildings
                .FirstOrDefaultAsync(b => b.Id == id && b.IsActive);

            if (building == null)
            {
                return Json(new { error = "Building not found" });
            }

            return Json(building);
        }

        [HttpGet]
        public async Task<JsonResult> SearchBuildings(string query, string category = null)
        {
            try
            {
                // Track the search in database
                int searchId = await _trackerService.TrackSearchAsync(query, category);

                // Search buildings in database
                var buildings = await _context.ARBuildings
                    .Where(b => b.IsActive &&
                               (b.Name.Contains(query) ||
                                b.Description.Contains(query) ||
                                b.Category.Contains(query)))
                    .OrderBy(b => b.Name)
                    .ToListAsync();

                // Store searchId in session to link with selection later
                HttpContext.Session.SetString($"LastSearch_{searchId}", searchId.ToString());

                return Json(new
                {
                    searchId = searchId,
                    results = buildings
                });
            }
            catch (Exception ex)
            {
                // Fallback to basic search if tracking fails
                var buildings = await _context.ARBuildings
                    .Where(b => b.IsActive &&
                               (b.Name.Contains(query) || b.Description.Contains(query)))
                    .OrderBy(b => b.Name)
                    .ToListAsync();

                return Json(new
                {
                    searchId = 0,
                    results = buildings
                });
            }
        }

        [HttpPost]
        public async Task<JsonResult> TrackBuildingSelection([FromBody] SelectionRequest request)
        {
            try
            {
                // Get the search results that were shown
                var searchResults = await _context.ARBuildings
                    .Where(b => b.IsActive && b.Name.Contains(request.SearchQuery) || b.Description.Contains(request.SearchQuery))
                    .Take(10)
                    .ToListAsync();

                await _trackerService.TrackSelectionAsync(request.SearchId, request.BuildingId, searchResults);

                return Json(new { success = true, message = "Selection tracked" });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<JsonResult> TrackNavigationStart([FromBody] NavigationRequest request)
        {
            try
            {
                await _trackerService.TrackNavigationStartAsync(request.SearchId, request.UserLocation);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<JsonResult> TrackNavigationComplete([FromBody] NavigationRequest request)
        {
            try
            {
                await _trackerService.TrackNavigationCompleteAsync(request.SearchId);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, error = ex.Message });
            }
        }

        [HttpGet]
        public async Task<JsonResult> GetBuildingsByCategory(string category)
        {
            // Filter buildings by category
            var buildings = await _context.ARBuildings
                .Where(b => b.IsActive && b.Category == category)
                .OrderBy(b => b.Name)
                .ToListAsync();

            return Json(buildings);
        }

        // Helper classes for JSON requests
        public class SelectionRequest
        {
            public int SearchId { get; set; }
            public int BuildingId { get; set; }
            public string SearchQuery { get; set; }
        }

        public class NavigationRequest
        {
            public int SearchId { get; set; }
            public string UserLocation { get; set; }
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index", "Login");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
