﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WayFindAR.Data;
using WayFindAR.Models;

namespace WayFindAR.Controllers
{
    public class RegisterController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RegisterController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
               
                // Create new user
                var user = new User
                {
                    FullName = model.FullName,
                    CampusId = model.CampusId,
                    Email = model.Email,
                    Username = model.Username,
                    PasswordHash = model.Password, // Store password directly
                    AccountType = model.AccountType,
                    CreatedAt = DateTime.Now,
                    IsActive = true
                };

                // Add to database
                _context.Users.Add(user);
                await _context.SaveChangesAsync();

                TempData["SuccessMessage"] = $"Account created for {model.FullName}! Please log in.";
                TempData["RegisteredUsername"] = model.Username;

                return RedirectToAction("Index", "Login");
            }

            return View(model);
        }
    }
}