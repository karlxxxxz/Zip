﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace WayFindAR.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "ARBuildings",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(500)", maxLength: 500, nullable: false),
                    Position = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    ModelType = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Category = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    FloorLevel = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    UpdatedAt = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ARBuildings", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    FullName = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    CampusId = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Username = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    AccountType = table.Column<string>(type: "nvarchar(20)", maxLength: 20, nullable: false),
                    CreatedAt = table.Column<DateTime>(type: "datetime2", nullable: false),
                    LastLoginAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DestinationSearches",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<int>(type: "int", nullable: true),
                    SearchQuery = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    SelectedBuildingId = table.Column<int>(type: "int", nullable: true),
                    SearchResults = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Category = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    UserLocation = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    DestinationCoordinates = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    SearchedAt = table.Column<DateTime>(type: "datetime2", nullable: false, defaultValueSql: "GETDATE()"),
                    SelectedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NavigationStartedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    NavigationCompletedAt = table.Column<DateTime>(type: "datetime2", nullable: true),
                    SearchResultCount = table.Column<int>(type: "int", nullable: false),
                    WasSuccessful = table.Column<bool>(type: "bit", nullable: false),
                    DeviceInfo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SessionId = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DestinationSearches", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DestinationSearches_ARBuildings_SelectedBuildingId",
                        column: x => x.SelectedBuildingId,
                        principalTable: "ARBuildings",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                    table.ForeignKey(
                        name: "FK_DestinationSearches_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.SetNull);
                });

            migrationBuilder.InsertData(
                table: "ARBuildings",
                columns: new[] { "Id", "Category", "CreatedAt", "Description", "FloorLevel", "IsActive", "ModelType", "Name", "Position", "UpdatedAt" },
                values: new object[,]
                {
                    { 1, "Administration", new DateTime(2025, 12, 15, 21, 46, 41, 115, DateTimeKind.Local).AddTicks(8895), "Administration and offices", "Ground Floor", true, "main", "Main Building", "0,0,0", null },
                    { 2, "Academic", new DateTime(2025, 12, 15, 21, 46, 41, 115, DateTimeKind.Local).AddTicks(8900), "Study resources center", "Ground Floor", true, "library", "Library", "2,0,1", null },
                    { 3, "Academic", new DateTime(2025, 12, 15, 21, 46, 41, 115, DateTimeKind.Local).AddTicks(8903), "Laboratories and research", "Level 1", true, "science", "Science Center", "-2,0,-1", null },
                    { 4, "Services", new DateTime(2025, 12, 15, 21, 46, 41, 115, DateTimeKind.Local).AddTicks(8907), "Food court and dining area", "Ground Floor", true, "cafeteria", "Main Cafeteria", "1,0,2", null }
                });

            migrationBuilder.InsertData(
                table: "Users",
                columns: new[] { "Id", "AccountType", "CampusId", "CreatedAt", "Email", "FullName", "IsActive", "LastLoginAt", "PasswordHash", "Username" },
                values: new object[] { 1, "Student", "CS2023001", new DateTime(2025, 12, 15, 21, 46, 41, 116, DateTimeKind.Local).AddTicks(4796), "student@campus.edu", "Test Student", true, null, "campus123", "student" });

            migrationBuilder.CreateIndex(
                name: "IX_ARBuildings_Name",
                table: "ARBuildings",
                column: "Name",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_DestinationSearches_Category",
                table: "DestinationSearches",
                column: "Category");

            migrationBuilder.CreateIndex(
                name: "IX_DestinationSearches_SearchedAt",
                table: "DestinationSearches",
                column: "SearchedAt");

            migrationBuilder.CreateIndex(
                name: "IX_DestinationSearches_SelectedBuildingId",
                table: "DestinationSearches",
                column: "SelectedBuildingId");

            migrationBuilder.CreateIndex(
                name: "IX_DestinationSearches_UserId",
                table: "DestinationSearches",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DestinationSearches");

            migrationBuilder.DropTable(
                name: "ARBuildings");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
