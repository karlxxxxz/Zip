﻿using Microsoft.AspNetCore.Http;
using WayFindAR.Data;
using WayFindAR.Models;

namespace WayFindAR.Services
{
    public class DestinationTrackerService
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public DestinationTrackerService(ApplicationDbContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;  // FIXED THIS LINE
        }

        // Track a search query
        public async Task<int> TrackSearchAsync(string searchQuery, string category = null)
        {
            var search = new DestinationSearch
            {
                SearchQuery = searchQuery,
                Category = category,
                SearchedAt = DateTime.Now,
                SessionId = GetSessionId(),
                DeviceInfo = GetDeviceInfo(),
                UserId = GetCurrentUserId()
            };

            _context.DestinationSearches.Add(search);
            await _context.SaveChangesAsync();

            return search.Id;
        }

        // Track when user selects a building from search results
        public async Task TrackSelectionAsync(int searchId, int buildingId, List<ARBuilding> searchResults)
        {
            var search = await _context.DestinationSearches.FindAsync(searchId);
            if (search != null)
            {
                search.SelectedBuildingId = buildingId;
                search.SelectedAt = DateTime.Now;
                search.SearchResultCount = searchResults?.Count ?? 0;
                search.SearchResults = System.Text.Json.JsonSerializer.Serialize(searchResults);
                search.WasSuccessful = true;

                // Get coordinates of selected building
                var building = await _context.ARBuildings.FindAsync(buildingId);
                if (building != null)
                {
                    search.DestinationCoordinates = building.Position;
                }

                await _context.SaveChangesAsync();
            }
        }

        // Track navigation start
        public async Task TrackNavigationStartAsync(int searchId, string userLocation = null)
        {
            var search = await _context.DestinationSearches.FindAsync(searchId);
            if (search != null)
            {
                search.NavigationStartedAt = DateTime.Now;
                search.UserLocation = userLocation;
                await _context.SaveChangesAsync();
            }
        }

        // Track navigation completion
        public async Task TrackNavigationCompleteAsync(int searchId)
        {
            var search = await _context.DestinationSearches.FindAsync(searchId);
            if (search != null)
            {
                search.NavigationCompletedAt = DateTime.Now;
                await _context.SaveChangesAsync();
            }
        }

        // Helper methods
        private string GetSessionId()
        {
            return _httpContextAccessor.HttpContext?.Session?.Id ?? Guid.NewGuid().ToString();
        }

        private string GetDeviceInfo()
        {
            var context = _httpContextAccessor.HttpContext;
            if (context == null) return "Unknown";

            var userAgent = context.Request.Headers["User-Agent"].ToString();
            return userAgent;  // FIXED: Removed duplicate $"{...}"
        }

        private int? GetCurrentUserId()
        {
            var context = _httpContextAccessor.HttpContext;
            if (context?.Session?.GetString("UserId") != null)
            {
                if (int.TryParse(context.Session.GetString("UserId"), out int userId))
                {
                    return userId;
                }
            }
            return null;
        }
    }
}